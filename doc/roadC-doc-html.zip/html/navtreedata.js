/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "roadC", "index.html", [
    [ "Introduction", "intro.html", [
      [ "Read-Only Array Data Compaction (roadC)", "intro.html#section3", [
        [ "Step 1: Input Transformation", "intro.html#subsection31", null ],
        [ "Step 2: Data Compaction", "intro.html#subsection32", [
          [ "Remove Sub-Arrays", "intro.html#subsection321", null ],
          [ "Greedy Approach", "intro.html#subsection322", null ]
        ] ],
        [ "Step 3: Output Generation", "intro.html#subsection33", null ]
      ] ],
      [ "Memory Handling", "intro.html#dataStructureAlignment", [
        [ "Data Alignment", "intro.html#subsectionDA", null ],
        [ "Data Structure Padding", "intro.html#subsectionPBB", null ],
        [ "Memory Protection", "intro.html#memoryProtection", null ]
      ] ],
      [ "Example in C", "intro.html#section4", [
        [ "Multidimensional Arrays", "intro.html#section6", null ]
      ] ],
      [ "Restrictions", "intro.html#section5", null ]
    ] ],
    [ "Implementation Details", "implementation.html", [
      [ "Data Alignment", "implementation.html#section7", [
        [ "Data Alignment when Removing Sub-Arrays", "implementation.html#dataAlignmentSubArrays", null ],
        [ "Data Alignment when concatenating arrays with overlap", "implementation.html#dataAlignmentMergeArrays", null ],
        [ "Data Alignment when concatenating arrays without overlap", "implementation.html#dataAlignmentConcatenateArrays", null ]
      ] ],
      [ "Data Structure Padding", "implementation.html#sectionD", [
        [ "Data Structure Padding when removing sub-arrays", "implementation.html#dataPaddingSubArrays", null ],
        [ "Data Structure Padding when concatenating arrays with overlap", "implementation.html#dataPaddingMergeArrays", null ],
        [ "Data Structure Padding when concatenating arrays without overlap", "implementation.html#dataPaddingConcatenateArrays", null ],
        [ "Data Structure Padding when searching for an input array position in the resulting compressed array", "implementation.html#dataPaddingResultingArray", null ]
      ] ],
      [ "Remove Sub-Arrays", "implementation.html#sectionA", null ],
      [ "Greedy Approach", "implementation.html#sectionB", [
        [ "Unnecessary Calculations", "implementation.html#sectionB1", null ],
        [ "Multiple Calculations", "implementation.html#sectionB2", null ]
      ] ],
      [ "Result Concatenation", "implementation.html#sectionC", null ]
    ] ],
    [ "Examples", "examples.html", null ],
    [ "License", "license.html", null ]
  ] ]
];

var NAVTREEINDEX =
[
"examples.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';